# ID-Management-Project-UI
Instruction:
[localpage] running on clients' local machine
--visit path: localpage-index.html
[UI-s-master] running on Blockchain server
--visit path: UI-s-master-login-main-index.html
